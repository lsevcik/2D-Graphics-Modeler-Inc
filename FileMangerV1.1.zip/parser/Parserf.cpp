#include "FileManager.h"

FileManager::FileManager(){}

FileManager::FileManager(std::ifstream &fin)
{
    ParseTextFile(fin);
}

FileManager::~FileManager(){}

int FileManager::GetShapeId()         const
{
    return shapeId;
}

std::string FileManager::GetShapeType()         const
{
    return shapeType;
}

std::vector<int> FileManager::GetShapeDimensions() const
{
    return shapeDimensions;
}

std::string FileManager::GetPenColor()        const
{
    return penColor;
}

int FileManager::GetPenWidth()                const
{
    return penWidth;
}

std::string FileManager::GetPenStyle()        const
{
    return penStyle;
}

std::string FileManager::GetPenCapStyle()     const
{
    return penCapStyle;
}

std::string FileManager::GetPenJoinStyle()    const
{
    return penJoinStyle;
}

std::string FileManager::GetBrushColor()      const
{
    return brushColor;
}

std::string FileManager::GetBrushStyle()      const
{
    return brushStyle;
}


std::string FileManager::GetTextString()      const
{
    return textString;
}

std::string FileManager::GetTextColor()       const
{
    return textColor;
}

std::string FileManager::GetTextAlignment()   const
{
    return textAlignment;
}

int FileManager::GetTextPointSize()           const
{
    return textPointSize;
}

std::string FileManager::GetTextFontFamily()  const
{
    return textFontFamily;
}

std::string FileManager::GetTextFontStyle()   const
{
    return textFontStyle;
}

std::string FileManager::GetTextFontWeight()  const
{
    return textFontWeight;
}

//COMMON MUTATORS
void FileManager::SetShapeId(int newVar)
{
    shapeId = newVar;
}

void FileManager::SetShapeType(std::string newVar)
{
    shapeType = newVar;
}

void FileManager::SetShapeDimensions(std::vector<int> newVar)
{
    shapeDimensions = newVar;
}

//SHAPE MUTATORS
void FileManager::SetPenColor(std::string newVar)
{
    penColor = newVar;
}

void FileManager::SetPenWidth(int newVar)
{
    penWidth = newVar;
}

void FileManager::SetPenStyle(std::string newVar)
{
    penStyle = newVar;
}

void FileManager::SetPenCapStyle(std::string newVar)
{
    penCapStyle = newVar;
}

void FileManager::SetPenJoinStyle(std::string newVar)
{
    penJoinStyle = newVar;
}

void FileManager::SetBrushColor(std::string newVar)
{
    brushColor = newVar;
}

void FileManager::SetBrushStyle(std::string newVar)
{
    brushStyle = newVar;
}

//TEXT MUTATORS
void FileManager::SetTextString(std::string newVar)
{
    textString = newVar;
}

void FileManager::SetTextColor(std::string newVar)
{
    textColor = newVar;
}

void FileManager::SetTextAlignment(std::string newVar)
{
    textAlignment = newVar;
}

void FileManager::SetTextPointSize(int newVar)
{
    textPointSize = newVar;
}

void FileManager::SetTextFontFamily(std::string newVar)
{
    textFontFamily = newVar;
}

void FileManager::SetTextFontStyle(std::string newVar)
{
    textFontStyle = newVar;
}

void FileManager::SetTextFontWeight(std::string newVar)
{
    textFontWeight = newVar;
}

void FileManager::SetAllShape(int newShapeId,
                 std::string newShapeType,
                 std::vector<int> newShapeDimensions,
                 std::string newPenColor,
                 int newPenWidth,
                 std::string newPenStyle,
                 std::string newPenCapStyle,
                 std::string newPenJoinStyle,
                 std::string newBrushColor,
                 std::string newBrushStyle)
{
    SetThree(newShapeId, newShapeType, newShapeDimensions);
    penColor     = newPenColor;
    penWidth     = newPenWidth;
    penStyle     = newPenStyle;
    penCapStyle  = newPenCapStyle;
    penJoinStyle = newPenJoinStyle;
    if(shapeType != "Line" && shapeType != "Polyline")
    {
        brushColor   = newBrushColor;
        brushStyle   = newBrushStyle;
    }
}

void FileManager::SetAllText(int newShapeId,
                std::string newShapeType,
                std::vector<int> newShapeDimensions,
                std::string newTextString,
                std::string newTextColor,
                std::string newTextAlignment,
                int newTextPointSize,
                std::string newTextFontFamily,
                std::string newTextFontStyle,
                std::string newTextFontWeight)
{
    SetThree(newShapeId, newShapeType, newShapeDimensions);
    textString     = newTextString;
    textColor      = newTextColor;
    textAlignment  = newTextAlignment;
    textPointSize  = newTextPointSize;
    textFontFamily = newTextFontFamily;
    textFontStyle  = newTextFontStyle;
    textFontWeight = newTextFontWeight;
}

void FileManager::ParseTextFile(std::ifstream &fin)
{
    std::string subHolder;

    fin.ignore(10000,'\n');
    //ShapeId:
    getline(fin, subHolder);
    subHolder = subHolder.substr(9,std::string::npos);
    shapeId = stoi(subHolder);

    //ShapeType
    getline(fin, subHolder);
    shapeType = subHolder.substr(11,std::string::npos);

    //ShapeDimensions
    SetShapeDimensions(fin);


    if(shapeType == "Text") //if Text
    {
        getline(fin, subHolder);
        textString = subHolder.substr(12, std::string::npos);

        getline(fin, subHolder);
        textColor = subHolder.substr(11, std::string::npos);

        getline(fin, subHolder);
        textAlignment = subHolder.substr(15, std::string::npos);

        getline(fin, subHolder);
        subHolder = subHolder.substr(15, std::string::npos);
        textPointSize = stoi(subHolder);

        getline(fin, subHolder);
        textFontFamily = subHolder.substr(16, std::string::npos);

        getline(fin, subHolder);
        textFontStyle = subHolder.substr(15, std::string::npos);

        getline(fin, subHolder);
        textFontWeight = subHolder.substr(16, std::string::npos);
    }
    else //if Shape
    {
        getline(fin, subHolder);
        penColor = subHolder.substr(10, std::string::npos);

        getline(fin, subHolder);
        subHolder = subHolder.substr(10, std::string::npos);
        penWidth = stoi(subHolder);

        getline(fin, subHolder);
        penStyle = subHolder.substr(10, std::string::npos);

        getline(fin, subHolder);
        penCapStyle = subHolder.substr(13, std::string::npos);

        getline(fin, subHolder);
        penJoinStyle = subHolder.substr(14, std::string::npos);

        if(shapeType != "Line" && shapeType != "Polyline")
        {
            getline(fin, subHolder);
            brushColor = subHolder.substr(12, std::string::npos);

            getline(fin, subHolder);
            brushStyle = subHolder.substr(12, std::string::npos);
        }

    }
    //fin.ignore(10000,'\n');
}

void FileManager::SetThree(int newShapeId,
                           std::string newShapeType,
                           std::vector<int> newShapeDimensions)
{
    shapeId         = newShapeId;
    shapeType       = newShapeType;
    shapeDimensions = newShapeDimensions;
}

void FileManager::SetShapeDimensions(std::ifstream &fin)
{
    std::string subHolder;
    std::string intHolder;
    int anchorIndex;
    int subIndex;

    anchorIndex = 0;

    getline(fin, subHolder);
    subHolder = subHolder.substr(17, std::string::npos);
    while(subHolder.find(", ") != std::string::npos)
    {
        subIndex = subHolder.find_first_of(',');
        intHolder = subHolder.substr(anchorIndex, subIndex);
        shapeDimensions.push_back(stoi(intHolder));
        subHolder = subHolder.substr(subIndex+2, std::string::npos);

    }
    shapeDimensions.push_back(stoi(subHolder));

}

std::string FileManager::GetShapeDimensions()
{
    std::ostringstream fout;
    int index;

    index = 0;

    while(index != shapeDimensions.size())
    {
        if(index == shapeDimensions.size()-1)
        {
            fout << shapeDimensions[index];
        }
        else
        {
            fout << shapeDimensions[index] << ", ";
        }
        index++;
    }

    return fout.str();
}

void FileManager::SaveTextFile(std::ofstream &fout) //This is a public function
{
         fout <<                                                std::endl
              << "ShapeId: "         << shapeId              << std::endl
              << "ShapeType: "       << shapeType            << std::endl
              << "ShapeDimensions: " << GetShapeDimensions() << std::endl;
    if(shapeId == 8)
    {
             fout << "TextString: "     << textString      << std::endl
                  << "TextColor: "      << textColor       << std::endl
                  << "TextAlignment: "  << textAlignment   << std::endl
                  << "TextPointSize: "  << textPointSize   << std::endl
                  << "TextFontFamily: " << textFontFamily  << std::endl
                  << "TextFontStyle: "  << textFontStyle   << std::endl
                  << "TextFontWeight: " << textFontWeight  << std::endl;


    }
    else
    {
             fout << "PenColor: "     << penColor     << std::endl
                  << "PenWidth: "     << penWidth     << std::endl
                  << "PenStyle: "     << penStyle     << std::endl
                  << "PenCapStyle: "  << penCapStyle  << std::endl
                  << "PenJoinStyle: " << penJoinStyle << std::endl;
        if(shapeType != "Line" && shapeType != "Polyline")
        {

                 fout << "BrushColor: "   << brushColor   << std::endl
                      << "BrushStyle: "   << brushStyle   << std::endl;
        }
    }
    //fout << std::endl;


}
