#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include<fstream>
#include<string>
#include<vector>
#include<iostream>
#include<sstream>
#include<typeinfo>

enum ShapeType
{
    Line,
    Polyline,
    Polygon,
    Rectangle,
    Square,
    Ellipse,
    Circle,
    Text
};

class FileManager
{
    public:
             FileManager();
             FileManager(std::ifstream &fin);
             FileManager(FileManager&) = delete;
             ~FileManager();
             FileManager operator=(FileManager&) = delete;

             //Accessors
             int GetShapeId()                      const;
             std::string GetShapeType()            const;
             std::vector<int> GetShapeDimensions() const;

             std::string GetPenColor()        const;
             int GetPenWidth()                const;
             std::string GetPenStyle()        const;
             std::string GetPenCapStyle()     const;
             std::string GetPenJoinStyle()    const;
             std::string GetBrushColor()      const;
             std::string GetBrushStyle()      const;

             std::string GetTextString()      const;
             std::string GetTextColor()       const;
             std::string GetTextAlignment()   const;
             int GetTextPointSize()           const;
             std::string GetTextFontFamily()  const;
             std::string GetTextFontStyle()   const;
             std::string GetTextFontWeight()  const;

             //Mutators
             void SetShapeId(int newVar)                     ;
             void SetShapeType(std::string newVar)           ;
             void SetShapeDimensions(std::vector<int> newVar);

             void SetPenColor(std::string newVar)      ;
             void SetPenWidth(int newVar)              ;
             void SetPenStyle(std::string newVar)      ;
             void SetPenCapStyle(std::string newVar)   ;
             void SetPenJoinStyle(std::string newVar)  ;
             void SetBrushColor(std::string newVar)    ;
             void SetBrushStyle(std::string newVar)    ;

             void SetTextString(std::string newVar)    ;
             void SetTextColor(std::string newVar)     ;
             void SetTextAlignment(std::string newVar) ;
             void SetTextPointSize(int newVar)         ;
             void SetTextFontFamily(std::string newVar);
             void SetTextFontStyle(std::string newVar) ;
             void SetTextFontWeight(std::string newVar);

             void SetAllShape(int newShapeId,
                              std::string newShapeType,
                              std::vector<int> newShapeDimensions,
                              std::string newPenColor,
                              int newPenWidth,
                              std::string newPenStyle,
                              std::string newPenCapStyle,
                              std::string newPenJoinStyle,
                              std::string newBrushColor,
                              std::string newBrushStyle);

             void SetAllText(int newShapeId,
                             std::string newShapeType,
                             std::vector<int> newShapeDimensions,
                             std::string newTextString,
                             std::string newTextColor,
                             std::string newTextAlignment,
                             int newTextPointSize,
                             std::string newTextFontFamily,
                             std::string newTextFontStyle,
                             std::string newTextFontWeight);

             void ParseTextFile(std::ifstream &fin);
             void SaveTextFile(std::ofstream &fout);

    private:
             int shapeId;
             std::string shapeType;
             std::vector<int> shapeDimensions;

             //For Shapes only
             std::string penColor;
             int penWidth;
             std::string penStyle;
             std::string penCapStyle;
             std::string penJoinStyle;
             std::string brushColor;
             std::string brushStyle;

             //For Text only
             std::string textString;
             std::string textColor;
             std::string textAlignment;
             int textPointSize;
             std::string textFontFamily;
             std::string textFontStyle;
             std::string textFontWeight;

             void SetThree(int newShapeId,
                           std::string newShapeType,
                           std::vector<int> newShapeDimensions); //A helper function for SetAllShape() and SetAllText()
             void SetShapeDimensions(std::ifstream &fin);
             std::string GetShapeDimensions();





};

#endif // FILEMANAGER_H
