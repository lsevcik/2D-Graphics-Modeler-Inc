#include"FileManager.h"

int main()
{
    FileManager Test[8];
    int index = 0;
    std::ifstream fin;
    std::ofstream fout;

    fin.open("data.txt");
    fout.open("SaveFile.txt");

    while(fin && index < 8)
    {

        Test[index].ParseTextFile(fin);
        Test[index].SaveTextFile(fout);
        index++;
    }

    fin.close();
    fout.close();
    return 0;
}
